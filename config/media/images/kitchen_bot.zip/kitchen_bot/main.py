import telebot
import config
from markups import get_contact,manu_main

config = config.config
bot = telebot.TeleBot(config)

@bot.message_handler(commands=['start'])
def welocme(message):
    bot.send_message(message.chat.id,'hey',reply_markup=get_contact())

@bot.message_handler(func=lambda message:True)
def all_echo(message):
    bot.send_message(message.chat.id,'fixed')

bot.polling()