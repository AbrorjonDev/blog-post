from telebot import types

def get_contact():
    
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    a = types.KeyboardButton("📞 Raqamni ulashish",request_contact=True)
    markup.add(a)
    return markup

def manu_main():
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True,row_width=2)
    a = types.KeyboardButton("🍲Таомлар")
    b = types.KeyboardButton("☕️Ичимликлар")
    c = types.KeyboardButton("ℹ️Таомлар ҳақида маълумотлар")
    d = types.KeyboardButton("📧Таклифлар юбориш")
    return markup.add(a,b,c,d)

