import sqlite3
from sqlite3.dbapi2 import OperationalError
import telebot
from telebot import types
import time
from datetime import *
now = datetime.now()
current_time = now.strftime("%H:%M:%S")
today = date.today()
d1 = today.strftime("%d/%m/%Y")



config = "1712480679:AAETTzh1yQVhFPOFkq3u0E3T5JV-XR0J58Y"
bot = telebot.TeleBot(config)

db = sqlite3.connect("sunlight.db") 
sql = db.cursor()


def get_contact():
    
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    a = types.KeyboardButton("📞 Raqamni ulashish",request_contact=True)
    markup.add(a)
    return markup

def manu_main():
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True,row_width=2)
    a = types.KeyboardButton("🍲Таомлар")
    b = types.KeyboardButton("☕️Ичимликлар")
    c = types.KeyboardButton("ℹ️Таомлар ҳақида маълумотлар")
    d = types.KeyboardButton("📧Таклифлар юбориш")
    return markup.add(a,b,c,d)

def send_welcome(message):
    chat_id = message.chat.id
    first_name = message.chat.first_name
    bot.send_message(chat_id,f"👨‍🍳 Assalomu aleykum!\n"
                                        f"{first_name}"
                                        f"🍽 Oshxonamizga Xush kelibsz!",reply_markup=manu_main())

try:
    @bot.message_handler(commands=['start'])
    def welcome(message):
        chat_id = message.chat.id
        first_name = message.chat.first_name
        # bot.send_message(chat_id,f"Hey {first_name}!",reply_markup=get_contact())
        bot.send_message(chat_id,f"Ботдан фойдаланиш учун рақамингизни улашинг❗️",reply_markup=get_contact())
        bot.register_next_step_handler(message,check_contact)
    
    @bot.message_handler(content_types=['contact'])
    def check_contact(message):
        first_name = message.chat.first_name
        chat_id = message.chat.id
        phone_number = message.contact.phone_number
        phone_number = int(phone_number)

        with sqlite3.connect("sunlight.db") as db:
          
            sql = db.cursor()
            sql.execute("SELECT chat_id FROM info_user WHERE chat_id=?",(chat_id,))
            items = (sql.fetchone())

            if items is None:
                sql.execute("""INSERT INTO info_user VALUES(?,?,?,?)""",(None,first_name,chat_id,phone_number,))
                db.commit()
                print("Users id has been saved successfully!")
                bot.register_next_step_handler(message,send_welcome)
            else:
                print("We have this id on date base")
                bot.register_next_step_handler(message,send_welcome)
        
                

        
        
        


except:
    pass    

bot.polling()